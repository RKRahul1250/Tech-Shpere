import React from 'react';

const SignUp = () => {
    return (
        <div>
            <h1>Hi</h1>
        </div>
    );
};

export default SignUp;